const express = require("express");
const router = express.Router();
const Message = require("../../models/Message");
const { authMiddleware, adminMiddleware } = require("../../utils/jwt");

// Удалить сообщение (только для админа)
router.delete("/:id", authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const message = await Message.findByIdAndDelete(req.params.id);
    if (!message) {
      return res.status(404).json({ error: "Сообщение не найдено" });
    }
    res.redirect("/messages"); // Перенаправляем обратно на страницу сообщений
  } catch (error) {
    res.status(500).json({ error: "Ошибка удаления" });
  }
});

module.exports = router;