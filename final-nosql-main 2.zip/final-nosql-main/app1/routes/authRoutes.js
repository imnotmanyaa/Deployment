const express = require("express");
const router = express.Router();
const User = require("../models/User");
const Message = require("../models/Message");
const bcrypt = require("bcrypt");
const crypto = require("crypto");
const { generateToken, verifyToken } = require("../utils/jwt");
const { registerSchema, loginSchema } = require("../middleware/validation");

// Middleware для проверки JWT
const authMiddleware = async (req, res, next) => {
  const token = req.cookies.jwt;
  if (!token) return res.redirect("/login");

  try {
    const decoded = verifyToken(token);
    req.user = await User.findById(decoded.userId);
    next();
  } catch (error) {
    res.clearCookie("jwt");
    res.redirect("/login");
  }
};

// Главная страница
router.get("/", (req, res) => {
  res.render("index", {
    title: "Главная",
    user: req.user || null,
    error: null,
  });
});

// Регистрация (GET)
router.get("/register", (req, res) => {
  res.render("register", {
    title: "Регистрация",
    user: null,
    error: null,
  });
});

// Регистрация (POST)
router.post("/register", async (req, res) => {
  try {
    const { error } = registerSchema.validate(req.body);
    if (error) throw new Error(error.details[0].message);

    const { name, email, password } = req.body;
    const existingUser = await User.findOne({ email });

    if (existingUser) {
      return res.render("register", {
        title: "Регистрация",
        error: "Email уже используется",
        user: null,
      });
    }

    const newUser = new User({ name, email, password });
    await newUser.save();

    const token = generateToken(newUser._id);
    res.cookie("jwt", token, { httpOnly: true });
    res.redirect("/dashboard");
  } catch (error) {
    res.render("register", {
      title: "Регистрация",
      error: error.message,
      user: null,
    });
  }
});

// Вход (GET)
router.get("/login", (req, res) => {
  res.render("login", {
    title: "Вход",
    user: null,
    error: null,
  });
});

// Вход (POST)
router.post("/login", async (req, res) => {
  try {
    const { error } = loginSchema.validate(req.body);
    if (error) throw new Error(error.details[0].message);

    const { email, password } = req.body;
    const user = await User.findOne({ email });

    if (!user || !(await user.comparePassword(password))) {
      return res.render("login", {
        title: "Вход",
        error: "Неверный email или пароль",
        user: null,
      });
    }

    const token = generateToken(user._id);
    res.cookie("jwt", token, { httpOnly: true });
    res.redirect("/dashboard");
  } catch (error) {
    res.render("login", {
      title: "Вход",
      error: error.message,
      user: null,
    });
  }
});

// Личный кабинет (GET)
router.get("/dashboard", authMiddleware, (req, res) => {
  res.render("dashboard", {
    title: "Личный кабинет",
    user: req.user,
  });
});

// Выход (GET)
router.get("/logout", authMiddleware, (req, res) => {
  res.clearCookie("jwt");
  res.redirect("/");
});

// Сообщения (GET)
router.get("/messages", authMiddleware, async (req, res) => {
  try {
    const messages = await Message.find({
      $or: [{ sender: req.user._id }, { receiver: req.user._id }],
    })
      .populate("sender receiver")
      .sort({ createdAt: -1 });

    const users = await User.find({ _id: { $ne: req.user._id } });

    res.render("messages", {
      title: "Сообщения",
      user: req.user,
      messages: messages,
      users: users,
    });
  } catch (error) {
    res.status(500).render("error", { error: "Ошибка загрузки сообщений" });
  }
});

// Отправка сообщения (POST)
router.post("/send-message", authMiddleware, async (req, res) => {
  try {
    const { receiverId, content } = req.body;
    if (!content || !content.trim()) return res.redirect("/messages");

    const receiver = await User.findById(receiverId);
    if (!receiver) return res.status(400).send("Пользователь не найден");

    const newMessage = new Message({
      sender: req.user._id,
      receiver: receiverId,
      content: content.trim(),
    });

    newMessage.generateHash();
    await newMessage.save();
    res.redirect("/messages");
  } catch (error) {
    res.status(500).render("error", { error: "Ошибка отправки сообщения" });
  }
});

module.exports = router;